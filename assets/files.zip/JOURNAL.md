# JOURNAL — Mt. Paul Card

---

## Session 1 — 2026-06-25

### What we did

Started from a conversation about shareable Artifacts and interactive tools. Explored options — options calculators, oracle tools — before landing on a focused, practical idea: a standalone digital scorecard PWA for Mt. Paul Golf Course.

The idea came from a real problem: arriving at the 2nd tee box and realizing nobody grabbed a paper scorecard. Paul wants to be able to text Dave (golf friend, also plays Mt. Paul) a link to the app so they can each keep their own score on their phones.

### Key decisions made

**Scope — what's IN:**
- Mt. Paul Blue tees only
- 9 holes looped twice = 18 holes
- Hole-by-hole counter (− / score / +)
- Par and yardage shown per hole
- Nav dots for progress, Back/Next buttons
- Front 9 scorecard after hole 9
- Full combined scorecard after hole 18
- Birdie = circle, bogey = square, double bogey+ = blush pink cell shading
- Scores persist via localStorage
- Full back-navigation to edit any hole
- End screen: New Round, Copy Scores, Print buttons
- No player name entry

**Scope — what's OUT:**
- Stats, toggles, analytics
- Multiple courses
- Settings screen
- Hole-in-One audio
- Player name / profiles
- Backend / Apps Script

**PWA:**
- Three files: index.html, manifest.json, sw.js
- GitHub Pages hosting (new repo — separate from golf-scores)
- Local folder: ~/Documents/Studio/Projects/MtPaulCard/
- Service Worker caches everything on first visit — fully offline after that
- Updates push automatically on next connected session

**Install flow:**
- iOS: Safari → Share → Add to Home Screen
- Android: Chrome → three-dot menu → Add to Home Screen
- Install landing page planned (Phase 1) to make this painless

**End of round:**
- Combined scorecard (front + back on one screen)
- Print to PDF via browser print dialog (user's choice)
- Copy scores to clipboard as plain text
- New Round button clears and returns to Hole 1

### Business angle explored

Mt. Paul uses Chronogolf for tee time booking. Phase 1: link button to their booking URL. Phase 2: embed their widget if available.

Full product vision mapped out:
- Phase 1: scorecard + install page + QR poster + Chronogolf link + GA4
- Phase 2: driving range, lessons (Breaking Par), restaurant menu, pro shop
- Phase 3: tournament calendar, sponsors, announcements

Platform play: template reusable for other Kamloops courses. Each gets own branding, QR codes, GA4, GitHub repo.

Decision maker at Mt. Paul: Dan Latin (owner) — or pro shop staff.

### Logo

Original Mt. Paul logo PNG uploaded (white on black, 886×330, RGBA).
Python/PIL used to extract white logo with transparent background.
Saved to: `assets/mt_paul_logo_transparent.png`
Use with CSS `mix-blend-mode` or directly on green background.
To be used with permission — placeholder for demo, discuss with club before going live.

### What's NOT built yet

- index.html
- manifest.json  
- sw.js
- Install landing page
- QR code poster
- PWA icons (192×192, 512×512)

### Next session — pick up here

1. Create GitHub repo `mt-paul-scorecard`
2. Build `index.html` — full 18-hole scorecard app
3. Build `manifest.json`
4. Build `sw.js`
5. Deploy to GitHub Pages
6. Test PWA install on phone
7. Share link with Dave as first real-world test

Upload to next session: `PROJECT.md`, `JOURNAL.md`, `CLAUDE.md`
